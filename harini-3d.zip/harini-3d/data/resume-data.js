const RESUME_DATA = {
  personal: {
    name: 'Harini S',
    title: 'Full Stack Developer',
    phone: '+91 7538892495',
    email: 'iamharinisivakumar@gmail.com',
    experience: '2.3 Years',
    location: 'Chennai, India',
    // placeholder until a real headshot is dropped in data/ - swap this path only, nothing else needs to change
    photo: 'data/logos/sysveda-logo.png'
  },
  hero: {
    heading: {
      desktop: 'Building secure trading platforms across Angular and Spring Boot.',
      mobile: 'Angular and Spring Boot for secure trading platforms.'
    },
    summary:
      'Full stack developer with hands-on delivery across Angular frontend development and Java Spring Boot backend services, building secure trading and advisory platforms for Australian financial institutions.',
    metrics: [
      { value: '2.3+', label: 'Years building production apps' },
      { value: '3', label: 'Australian trading platforms delivered' },
      { value: 'Angular + Java', label: 'Balanced frontend and backend ownership' }
    ]
  },
  profile:
    'I build end-to-end web applications with equal focus on Angular frontend delivery and Java Spring Boot backend engineering. My recent work includes RESTful microservices, secure JWT authentication, real-time WebSocket dashboards, and reusable UI systems delivered inside Agile Scrum teams.',
  education: {
    degree: 'MCA',
    college: 'Sri Venkateswara College of Engineering',
    year: '2025 - Current'
  },
  skills: {
    frontend: ['Angular', 'PrimeNG', 'Bootstrap', 'PrimeFlex', 'TypeScript', 'JavaScript', 'HTML5', 'CSS3', 'SCSS'],
    backend: ['Java', 'Spring Boot', 'Servlet / JSP (J2EE)', 'Microservices', 'JPA / Hibernate', 'Spring Security'],
    cloud: ['Redis', 'Eureka Server', 'API Gateway', 'Feign Client', 'Jenkins'],
    data: ['PostgreSQL', 'MySQL', 'SQL Optimization', 'WebSocket / STOMP', 'JWT Auth'],
    tools: ['Git', 'GitHub', 'JIRA', 'Visual Studio Code', 'STS', 'Eclipse']
  },
  signals: [
    { value: 'Full stack delivery', label: 'Built both Angular user flows and Spring Boot service integrations' },
    { value: 'Finance domain', label: 'Experience in Australian trading and advisory platforms with secure workflows' },
    { value: 'Microservices', label: 'Hands-on with Eureka, API Gateway, Feign Client, and JWT-secured services' },
    { value: 'Agile delivery', label: 'Comfortable with estimation, reviews, debugging, demos, and support' }
  ],
  experience: [
    {
      company: 'Sysveda Information Technology Pvt Ltd, Chennai',
      logo: { src: 'data/logos/sysveda-logo.png', alt: 'Sysveda logo' },
      role: 'Software Engineer',
      duration: 'July 2024 - Present',
      project: 'Adviser Portal',
      client: 'AUSIEX, Grove Securities, Equity and Super - Private Asset Management, Australia',
      description:
        'Building secure web-based trading and advisory platforms for Australian financial institutions, covering equity trading, portfolio management, real-time market insights, and research access within a unified, responsive interface.',
      responsibilities: [
        'Developed and maintained RESTful microservices using Java, Spring Boot, JPA, and Hibernate for scalable backend architecture.',
        'Built secure authentication flows using Spring Security and JWT-based role authorization.',
        'Improved response times through asynchronous API processing and SQL optimization using indexes, functions, and materialized views.',
        'Integrated Feign Client, Eureka Server, and API Gateway for service discovery, routing, and API-level security.',
        'Centralized environment configuration using GitHub-based config repositories for stable CI/CD deployments.',
        'Upgraded Angular applications from v15 to v19 with standalone components, custom directives, and lazy-loaded modules.',
        'Integrated STOMP.js WebSockets, Auth Guards, and HTTP Interceptors for real-time, secure, role-based experiences.',
        'Implemented dynamic theming, multi-language i18n, and Chart.js-powered dashboards for richer data visualization.'
      ],
      techStack: ['Angular', 'Java 11', 'Spring Boot', 'Spring Security', 'Hibernate', 'Microservices', 'Redis', 'PostgreSQL', 'Jenkins', 'Git', 'PrimeNg'],
      caseStudy: {
        title: 'Adviser & Trading Portal',
        summary: 'Full stack contribution across Angular workflows and Spring Boot-backed trading services for Australian financial institutions, where security, performance, and clarity all mattered.',
        bullets: [
          'Built Angular-based trading and advisory journeys with dynamic theming and reusable components.',
          'Delivered secure Spring Boot microservices with JWT auth, Eureka, and API Gateway integration.',
          'Added real-time WebSocket notifications and Chart.js dashboards for richer market insights.'
        ]
      }
    }
  ],
  languages: ['English', 'Tamil'],
  workflow: [
    'Daily stand-up meetings and sprint planning',
    'Task estimation and backlog refinement',
    'UI implementation with Angular, HTML, CSS, Bootstrap, and JavaScript',
    'Backend development with Java, SQL, and Spring Boot',
    'Sprint demos, retrospectives, and stakeholder feedback',
    'Documentation and knowledge sharing'
  ]
};
